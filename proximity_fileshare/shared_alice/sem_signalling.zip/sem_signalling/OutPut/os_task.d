.\output\os_task.o: uCosii\OS_TASK.C
.\output\os_task.o: uCosii\..\APP\includes.h
.\output\os_task.o: uCosii\..\APP\..\uCosii\os_cpu.h
.\output\os_task.o: uCosii\..\APP\os_cfg.h
.\output\os_task.o: uCosii\..\APP\..\uCosii\ucos_ii.h
.\output\os_task.o: C:\Keil\ARM\ARMCC\bin\..\include\string.h
