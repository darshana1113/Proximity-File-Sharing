.\output\os_mbox.o: uCosii\OS_MBOX.C
.\output\os_mbox.o: uCosii\..\APP\includes.h
.\output\os_mbox.o: uCosii\..\APP\..\uCosii\os_cpu.h
.\output\os_mbox.o: uCosii\..\APP\os_cfg.h
.\output\os_mbox.o: uCosii\..\APP\..\uCosii\ucos_ii.h
.\output\os_mbox.o: C:\Keil\ARM\ARMCC\bin\..\include\string.h
