.\output\os_time.o: uCosii\OS_TIME.C
.\output\os_time.o: uCosii\..\APP\includes.h
.\output\os_time.o: uCosii\..\APP\..\uCosii\os_cpu.h
.\output\os_time.o: uCosii\..\APP\os_cfg.h
.\output\os_time.o: uCosii\..\APP\..\uCosii\ucos_ii.h
.\output\os_time.o: C:\Keil\ARM\ARMCC\bin\..\include\string.h
