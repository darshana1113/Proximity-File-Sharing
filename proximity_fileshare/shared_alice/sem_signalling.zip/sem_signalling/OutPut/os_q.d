.\output\os_q.o: uCosii\OS_Q.C
.\output\os_q.o: uCosii\..\APP\includes.h
.\output\os_q.o: uCosii\..\APP\..\uCosii\os_cpu.h
.\output\os_q.o: uCosii\..\APP\os_cfg.h
.\output\os_q.o: uCosii\..\APP\..\uCosii\ucos_ii.h
.\output\os_q.o: C:\Keil\ARM\ARMCC\bin\..\include\string.h
