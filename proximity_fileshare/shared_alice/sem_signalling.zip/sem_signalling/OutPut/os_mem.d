.\output\os_mem.o: uCosii\OS_MEM.C
.\output\os_mem.o: uCosii\..\APP\includes.h
.\output\os_mem.o: uCosii\..\APP\..\uCosii\os_cpu.h
.\output\os_mem.o: uCosii\..\APP\os_cfg.h
.\output\os_mem.o: uCosii\..\APP\..\uCosii\ucos_ii.h
.\output\os_mem.o: C:\Keil\ARM\ARMCC\bin\..\include\string.h
