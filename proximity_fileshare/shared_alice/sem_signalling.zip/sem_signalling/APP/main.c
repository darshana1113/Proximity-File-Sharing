
#include"config.h"
#include"stdlib.h"
#include<LPC21XX.h>


OS_STK Task1Stack[100];
void Task1(void *pdata);

OS_STK Task2Stack[256];
void Task2(void *pdata);

static OS_EVENT *semaphore;

int main(void)
{
	//keyinit();
	LCD_init();
	LCD_cmd(0x80);

	OSInit();
	semaphore=OSSemCreate(0); //semaphore created
	//if(semaphore!=NULL)
	//{
	//	LCD_display(1,1,"Sema create"); //Confirming sucessful creation of semphore
	//}
	//else
	//{
	//	LCD_display(1,1,"Sema not create"); // displaying msg incase semaphore is not created sucessfully
		//delay1();
		//delay1();
	//}
    

	OSTaskCreate(Task1,(void *)0,&Task1Stack[99],0); // task created
	OSTaskCreate(Task2,(void *)0,&Task2Stack[255],1);

	OSStart(); // start multitasking
	return 0;
}

void Task1(void *pdata)
{
	int n,i;
	char err;
	pdata=pdata;
	LCD_init(); // LCD initialization

	while(1)
	{
		
		LCD_display(1,1,"starting task1");
		for(i=0;i<900000;i++);
		clrscreen();
		
		LED_FLASH_ThirdNibble();
		//for(i=0;i<900000;i++);
		//OSSemPost(semaphore);  // Released Semaphore
		OSSemPend(semaphore,200,&err); // Acuired Semaphore
		//OSTimeDlyHMSM(0,0,2,0);
	}
}

void Task2(void *pdata)
{
	int n,i;
	unsigned int temp2;
	char buf[16];
	//char buf1=0x100;
 char buf1[] = "0x166";
	char err;
	pdata=pdata;
	LCD_init();
	
		LCD_display(1,1,"ADC ON");
		//OSSemPend(semaphore,1,&err);
		//LCD_display(1,1,"Task1:Releasing Sem");
		for(i=0;i<900000;i++);
	clrscreen();
	while(1)
	{		
		ADC_Read(1);

	  PINSEL1 = 0x05000000;   // select adc channel AD0.1 and AD0.2
		
		temp2 = ADC_Read(1);							//read AN0.1
		
		if(temp2<=0x166)
		{
		sprintf(buf,"ADC:0x%03x ",temp2);		//convert to string and store in a buffer
		LCD_display(1,1,buf);
		}
		else
		{
			LCD_display(1,1,"set point");
		for(i=0;i<900000;i++);
			clrscreen();
		OSSemPost(semaphore);
		}
	}
}


